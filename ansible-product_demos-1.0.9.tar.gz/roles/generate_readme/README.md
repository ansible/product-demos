# Generate README

This Ansible Role will generate the master README.md for this Ansible Collection.

To generate a README.md, execute the following command from the root of this Ansible Collection.

```
ansible-playbook playbooks/generate_readme.yml
```

Please see the result at the master demo [README.md](../../README.md)
